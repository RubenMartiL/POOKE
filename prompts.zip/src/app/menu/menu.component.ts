import { Component, EventEmitter, Input, Output } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-menu',
  templateUrl: './menu.component.html',
  styleUrls: ['./menu.component.css']
})
export class MenuComponent {
  userLoged: string | null = '';

  activeSection: string = 'home';
  @Input() activeMenuHome:string = '';
  @Output() activeMenu = new EventEmitter();

  constructor(private router: Router) {
    this.userLoged = localStorage.getItem('login');
  }

  logout = () => {
    localStorage.removeItem("login");
    this.router.navigate(['']);
  }

  navigation = (seccion: string) => {
    this.activeSection = seccion;
    this.activeMenu.emit(this.activeSection);
  }
}
