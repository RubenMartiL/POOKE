import { Component } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent {
  nickname: string = '';
  password: string = '';
  error: string = '';

  constructor(private router : Router){}

  login = () => {
    const myInit = {
      method: 'POST',
      body: JSON.stringify({nickname: this.nickname, password: this.password}) 
    }
    fetch('http://localhost/pokemon/pokemonServer/login.php', myInit)
      .then(response => response.json())
      .then(data => {
        if(data) {
          localStorage.setItem("login",this.nickname);
          this.router.navigate(['game']);
        }else{
          this.error = 'No coincide';
        }
      })
  }
}
